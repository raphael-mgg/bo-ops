# Backoffice Alpha Capital — Projeto Completo

Simulação de um dia de operação de backoffice de gestora de recursos, integrando **Excel + VBA + Python + Power BI**. Pensado como portfólio pra processo seletivo.

---

## 📁 Estrutura

```
alpha_capital/
├── dados/                      # dados sintéticos da gestora
│   ├── posicao_inicial.csv     # carteira no D-1
│   └── boletas_mesa.csv        # operações registradas pela mesa
│
├── corretoras/                 # arquivos enviados pelas corretoras
│   ├── XP_boletas_20260428.csv         # ; latin-1, vírgula decimal
│   ├── BTG_trades_20260428.csv         # , utf-8, BUY/SELL em inglês
│   ├── ITAU_BBA_op_20260428.txt        # | pipe-separated
│   └── BRADESCO_corretora_20260428.csv # ; com cabeçalho "humano"
│
├── custodia/                   # posição enviada pelo custodiante
│   └── posicao_custodia_20260428.csv
│
├── precos/                     # preços de fechamento da B3
│   └── precos_b3_20260428.csv
│
├── scripts/                    # Python
│   ├── gerar_dados.py          # gera todos os arquivos sintéticos
│   ├── gerar_excel.py          # gera o Excel mestre
│   └── backoffice_alpha.py     # ⭐ pipeline principal (concil. + MtM + PL)
│
├── output/                     # resultados gerados
│   ├── Backoffice_Alpha_Capital.xlsx   # planilha-mestre c/ macros
│   ├── macros_backoffice.bas           # módulo VBA pra importar no Excel
│   ├── backoffice_resultado.xlsx       # output do Python (4 abas)
│   └── powerbi_data/                   # CSVs prontos pro Power BI
│       ├── fato_boletas.csv
│       ├── fato_posicoes.csv
│       ├── fato_pl_fundos.csv
│       ├── fato_conciliacao.csv
│       └── dim_fundos.csv
│
└── docs/                       # documentação
    ├── POWER_BI.md             # estrutura, modelagem e medidas DAX
    └── FLUXOS_LIQUIDACAO.md    # D+1/D+2/Selic/B3/SPB
```

---

## 🚀 Como rodar

### 1) Gerar dados sintéticos

```bash
cd alpha_capital
python scripts/gerar_dados.py
```

### 2) Gerar Excel-mestre

```bash
python scripts/gerar_excel.py
```
→ produz `output/Backoffice_Alpha_Capital.xlsx`

### 3) Importar macros VBA no Excel

1. Abra `output/Backoffice_Alpha_Capital.xlsx`
2. **Salvar como** → tipo **Pasta de Trabalho Habilitada para Macro (.xlsm)**
3. **Alt+F11** → menu **File → Import File** → escolha `output/macros_backoffice.bas`
4. Ajuste a aba **Parametros** com o caminho real da pasta `corretoras/` no seu PC
5. **Alt+F8** → execute `AtualizarTudo`

### 4) Rodar pipeline Python (conciliação + MtM)

```bash
python scripts/backoffice_alpha.py
```

### 5) Power BI

Siga `docs/POWER_BI.md`. Importe os CSVs de `output/powerbi_data/`, monte o modelo em estrela, copie as medidas DAX e construa as 4 páginas sugeridas.

---

## 🎯 O que esse projeto demonstra (pra entrevista)

| Habilidade técnica                       | Onde aparece                                    |
|------------------------------------------|-------------------------------------------------|
| Excel: PROCV, SOMASES, formatação cond.  | Planilha-mestre, abas de controle               |
| VBA: macros, loops, manipulação Range    | `macros_backoffice.bas` (4 macros funcionais)   |
| VBA: tratamento de múltiplos layouts     | `ImportarBoletasCorretoras` (4 importadores)    |
| Python: pandas, merge, groupby           | `backoffice_alpha.py`                           |
| Python: limpeza de dados, ETL            | Carga + normalização de CSV de fontes diversas  |
| Modelagem: esquema estrela               | `docs/POWER_BI.md`                              |
| Power BI: DAX, time intelligence         | Medidas no `docs/POWER_BI.md`                   |
| Domínio de negócio: fluxos B3/Selic      | `docs/FLUXOS_LIQUIDACAO.md`                     |
| Domínio: marcação a mercado, cota, PL    | Função `marcar_mercado` e `calcular_pl_e_cota`  |
| Domínio: conciliação custódia            | Função `conciliar_custodia`                     |

---

## 🧠 Conceito por trás da arquitetura

A divisão de ferramentas não é aleatória — segue a lógica real de uma gestora:

- **Excel** é o chão de fábrica do backoffice. Visual, flexível, todo mundo conhece.
- **VBA** automatiza as repetições do Excel — especialmente quando tem que lidar com **N corretoras com N layouts diferentes**, que é o cenário real.
- **Python** entra quando o volume estoura o Excel ou quando o cálculo é complexo (marcação a mercado vetorizada, integração com APIs/bancos, conciliação de dezenas de milhares de linhas).
- **Power BI** é a vitrine — transforma o que Excel/VBA/Python produzem em painéis que o gestor, sócio e compliance leem em segundos.

Mostrar que você entende **qual ferramenta serve pra qual problema** já te coloca à frente de quem só sabe "fazer no Excel" ou "fazer no Python".

---

## 📚 O que estudar pra cada parte

**Excel/VBA:** PROCV, ÍNDICE+CORRESP, SOMASES, tabela dinâmica, gravar e editar macro, loops `For` e `Do While`, `Range/Cells`, abrir/fechar workbooks, tratamento de erro `On Error`.

**Python:** `pandas` (read_csv/excel, merge, groupby, pivot_table, fillna, to_excel), `numpy.where`, list/dict comprehensions, leitura de arquivos com encodings diferentes.

**Power BI:** Power Query (importação, mesclar, despivotar), modelagem em estrela, DAX (`SUM`, `CALCULATE`, `FILTER`, `DIVIDE`, `DATESYTD`, `SAMEPERIODLASTYEAR`), construção de relatórios.

**Negócio (essencial pra backoffice de gestora):**
- Fluxos D+0/D+1/D+2 e câmaras (B3, Selic, SPB)
- Conceito de marcação a mercado vs marcação na curva
- PL, cota, cotização, come-cotas
- Resolução CVM 175 (novo marco dos fundos)
- Eventos corporativos (dividendo, JCP, bonificação, split, subscrição)
- ANBIMA e divulgação de cota
