# Fluxos de Liquidação no Brasil — Guia Rápido pro Backoffice

Esse documento cobre o essencial que cai em entrevista de backoffice de gestora ou em prova prática. Foco em entender **quem liquida o quê, em quanto tempo, e por qual câmara**.

---

## 1) Conceitos base

**Data de operação (D0):** dia em que a operação foi executada na bolsa/balcão.

**Data de liquidação (D+n):** dia em que **dinheiro e ativo trocam de mãos de fato**. Antes disso, a operação está "negociada" mas não "liquidada". É no D+n que sai o caixa do fundo e o ativo entra na custódia.

**Princípio DvP (Delivery vs Payment):** o ativo só é entregue ao comprador no exato momento em que o dinheiro é creditado ao vendedor. Garantia básica de mercado moderno — quem opera entrega DvP no Brasil é a B3 (na ponta de compensação).

---

## 2) Prazos de liquidação por classe de ativo

| Ativo                          | Liquidação | Câmara          |
|--------------------------------|------------|-----------------|
| Ações à vista                  | **D+2**    | B3 (Câmara BM&FBOVESPA) |
| Opções (compra/venda do prêmio)| **D+1**    | B3              |
| Termo de ações                 | D+1 ou prazo combinado | B3 |
| Futuros (DI, DOL, IND, BGI)    | Ajuste diário **D+1** | B3 |
| Tesouro Direto / Selic (LFT, NTN-B, LTN, NTN-F) | **D+1** | Selic (BCB) |
| CDB, LCI, LCA, debêntures, CRI, CRA | **D+0** ou **D+1** (negociado) | B3 (antiga Cetip) |
| Dólar pronto/casado            | **D+2**    | B3 / SPB        |
| Cotas de fundos (aplicação/resgate) | conforme regulamento (D+0 a D+30) | escrituradora |

> **Mudança de 2024:** ações migraram de **D+2** para algumas tentativas de **D+1** seguindo movimento dos EUA. Confirme a regra atual da B3 antes da prova — esse é o tipo de detalhe que diferencia o candidato.

---

## 3) As três câmaras que importam

### B3 (Brasil, Bolsa, Balcão)

Câmara única que resultou da fusão BM&FBovespa + Cetip (2017). Liquida:
- Tudo que é negociado em bolsa (ações, derivativos, ETF, BDR)
- Renda fixa privada que era da antiga Cetip (CDB, debêntures, LCI/LCA, CRI/CRA)
- Cotas de fundos imobiliários

### Selic (Sistema Especial de Liquidação e Custódia)

Operada pelo **Banco Central**. Liquida exclusivamente **títulos públicos federais**:
- LFT (Tesouro Selic)
- LTN (Tesouro Prefixado)
- NTN-B (Tesouro IPCA+)
- NTN-F (Tesouro Prefixado com cupom)
- Operações compromissadas (repo) com títulos públicos

Custódia também fica no Selic. É um sistema **DvP em tempo real** entre instituições financeiras.

### SPB (Sistema de Pagamentos Brasileiro)

Não é uma câmara em si, é o **conjunto de sistemas de pagamento** do país (STR, SITRAF, SILOC, CIP, e o próprio Selic). Pra backoffice, o que interessa é:

- **STR (Sistema de Transferência de Reservas):** mensagens de pagamento de **alto valor** entre bancos, em tempo real. É o "trilho" por onde anda o caixa que liquida operações grandes (como compra de bloco de ações ou aplicação em fundo).
- **CIP (hoje TecBan/Nuclea):** liquida TEDs e DOCs.

---

## 4) O dia D do backoffice — visão de fluxo

```
D-1 (véspera):
  • Mesa opera: 25 boletas
  • À noite: corretoras geram arquivos de "Trade Date" e enviam ao backoffice

D0 (hoje, conferência):
  08h │ Backoffice importa arquivos das corretoras
  09h │ Casa boletas mesa x corretora → trata divergências
  10h │ Calcula necessidade de caixa por fundo
       │
       │ ┌─ Ações compradas em D-1 → liquidam em D+1 (1 dia útil à frente)
       │ │  Backoffice precisa garantir CAIXA no fundo até D+1 ~16h
       │ │
       │ ├─ Renda fixa pública comprada em D-1 → liquida HOJE (D+1 do trade)
       │ │  Backoffice confirma comando no Selic
       │ │
       │ └─ Renda fixa privada → liquida HOJE ou amanhã, conforme negociado
       │
  14h │ Recebe posição da custódia → concilia (Python)
  15h │ Marca a mercado, calcula PL e cota do dia
  16h │ Envia comandos de liquidação pendentes (B3, Selic)
  17h │ Gera/envia cota à ANBIMA e CVM
  18h │ Atualiza dashboards (Power BI), backup, fechamento

D+1 (amanhã):
  • As ações operadas em D-1 efetivamente liquidam (DvP B3)
  • Caixa sai da conta liquidação do fundo, ativo entra na custódia
```

---

## 5) Onde tudo dá errado (e o backoffice corre)

### Quebra de boleta (mesa x corretora)

O gestor digitou 10.000 PETR4 a R$ 38,40 mas a corretora registrou 10.000 PETR4 a R$ 38,45. **Quem está certo?** Geralmente a corretora (porque é quem executou de verdade na bolsa). Mas pode ter havido erro de digitação no OMS da corretora também. Resolução: ouvir a gravação do "voice trade" ou consultar log do FIX/algoritmo.

**Impacto se não tratar:** divergência no PL calculado vs PL real, erro na cota.

### Falha de liquidação financeira (shortfall)

Fundo não tem caixa pra honrar a compra de D+2. Custodiante avisa o gestor de manhã. Soluções:
- Resgate emergencial de fundo DI da própria gestora
- Venda de LFT (renda fixa pública liquida em D+1, então dá pra "casar")
- Linha overnight com banco custodiante (caro, evitar)

**Impacto se não resolver:** multa da B3, possível execução de garantias, dano reputacional. Em casos extremos, **fail to deliver**.

### Falha de custódia (custodiante x interno)

A posição que a gestora calcula internamente diverge da posição que o custodiante reporta. Causas comuns:
- Evento corporativo não tratado (dividendo, JCP, bonificação, split, grupamento, subscrição)
- Empréstimo de ações (BTC) não controlado
- Boleta cancelada na bolsa mas não cancelada internamente
- Erro de classe de ação (PETR4 vs PETR3)

**Impacto:** PL calculado errado → cota errada → cotista entra/sai pelo preço errado → eventual indenização e problema com CVM.

### Cota errada divulgada

Acontece. ANBIMA tem prazo até 22h pra divulgar a cota do dia. Se errou, **republica** com a cota correta. Se afetou cotista que aplicou/resgatou, **a gestora indeniza**. Por isso o fechamento de cota é o momento mais sensível do dia.

---

## 6) Regulação e relatórios obrigatórios (resumão)

- **CVM:** Resolução CVM 175 (novo marco dos fundos, em vigor desde out/2023). Define quem é gestor, administrador, custodiante.
- **ANBIMA:** divulgação diária de cota, classificação de fundos, autorregulação.
- **Banco Central:** quem opera Selic, CMN edita normas de capital.
- **Receita Federal:** **CCS** (Cadastro de Clientes do SFN), **e-Financeira**, IR sobre operações.

Reportes diários típicos do backoffice:
1. **Cota e PL** → ANBIMA (até 22h)
2. **Composição da carteira** (CDA mensal) → CVM
3. **Posições** → Custodiante (pra reconciliação D+1)
4. **Risco** → controles internos (VaR, exposição, enquadramento)

---

## 7) Glossário rápido pra prova

| Termo | Significado |
|-------|------|
| OMS | Order Management System — sistema da mesa pra registrar ordens |
| EMS | Execution Management System — roteamento de ordens pra corretoras |
| FIX | Protocolo de mensageria padrão (Financial Information eXchange) |
| Boleta | Registro de uma operação (uma execução completa) |
| Liquidação física | Entrega do ativo |
| Liquidação financeira | Pagamento em dinheiro |
| DvP | Delivery vs Payment — troca simultânea |
| PU | Preço Unitário (renda fixa) |
| Marcação a mercado (MtM) | Avaliar posição pelo preço atual de mercado |
| Marcação na curva | Avaliar posição pela curva de juros original (mantida até vencimento) |
| Cota patrimonial | PL ÷ qtd de cotas em circulação |
| Cotização | Data em que o cotista efetivamente entra/sai pelo valor da cota |
| Come-cotas | Antecipação semestral de IR em fundos abertos |
