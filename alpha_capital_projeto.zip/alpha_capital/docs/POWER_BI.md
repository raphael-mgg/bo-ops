# Power BI — Dashboard Alpha Capital

Estrutura completa do dashboard de backoffice. Os dados vêm dos CSVs gerados pelo Python (`output/powerbi_data/`).

---

## 1) Importação no Power Query

No Power BI Desktop: **Página Inicial → Obter Dados → Texto/CSV** e importe na ordem:

| Arquivo                  | Tabela no modelo       | Tipo    |
|--------------------------|------------------------|---------|
| `fato_boletas.csv`       | `fBoletas`             | Fato    |
| `fato_posicoes.csv`      | `fPosicoes`            | Fato    |
| `fato_pl_fundos.csv`     | `fPLFundos`            | Fato    |
| `fato_conciliacao.csv`   | `fConciliacao`         | Fato    |
| `dim_fundos.csv`         | `dFundos`              | Dimensão|

### Tratamentos no Power Query

Para cada fato com data, garanta que a coluna seja do tipo **Date**:

```m
// Etapa típica em fBoletas
= Table.TransformColumnTypes(Origem, {
    {"data_operacao", type date},
    {"data_liquidacao", type date},
    {"quantidade", Int64.Type},
    {"preco", type number},
    {"valor_financeiro", type number}
})
```

Em `fConciliacao` e `fPosicoes`, garanta que `qtd_interno`, `qtd_custodia`, `valor_mercado` e `pnl_dia` sejam **número decimal**.

---

## 2) Tabela calendário (DAX)

Em **Modelagem → Nova Tabela**:

```dax
dCalendario =
ADDCOLUMNS(
    CALENDAR(DATE(2026,1,1), DATE(2026,12,31)),
    "Ano",        YEAR([Date]),
    "Mês",        FORMAT([Date], "MMM"),
    "MêsNum",     MONTH([Date]),
    "Trimestre",  "T" & FORMAT([Date], "Q"),
    "DiaSemana",  FORMAT([Date], "dddd"),
    "DiaUtil",    IF(WEEKDAY([Date],2) <= 5, 1, 0)
)
```

Marque como **Tabela de Datas** (botão direito → Marcar como tabela de datas → coluna `Date`).

---

## 3) Modelagem (esquema estrela)

Relacionamentos a criar (todos 1:N, direção única da dimensão pra fato):

```
dCalendario[Date]   → fBoletas[data_operacao]
dCalendario[Date]   → fPLFundos[data_pregao]

dFundos[fundo]      → fBoletas[fundo]
dFundos[fundo]      → fPosicoes[fundo]
dFundos[fundo]      → fPLFundos[fundo]
dFundos[fundo]      → fConciliacao[fundo]
```

Esquema visual:

```
                 dCalendario
                      │
                      ▼
   ┌──── fBoletas ◄── dFundos ──► fPLFundos
   │                    │
   ▼                    ▼
fPosicoes          fConciliacao
```

---

## 4) Medidas DAX essenciais

Crie uma tabela vazia chamada `_Medidas` (Inserir → Inserir Dados → tabela vazia) e coloque todas as medidas lá pra organização.

### PL e rentabilidade

```dax
PL Total = SUM(fPLFundos[pl_total])

PL Ativos = SUM(fPosicoes[valor_mercado])

Rentabilidade Dia =
AVERAGEX(
    VALUES(fPLFundos[fundo]),
    CALCULATE(SUM(fPLFundos[rentabilidade_dia]))
)

Rentabilidade Dia % = FORMAT([Rentabilidade Dia], "0.0000%")

PnL Dia = SUM(fPosicoes[pnl_dia])
```

### Boletas e volume

```dax
Qtd Boletas = COUNTROWS(fBoletas)

Volume Financeiro = SUM(fBoletas[valor_financeiro])

Volume Compras =
CALCULATE([Volume Financeiro], fBoletas[lado] = "C")

Volume Vendas =
CALCULATE([Volume Financeiro], fBoletas[lado] = "V")

Saldo Líquido = [Volume Vendas] - [Volume Compras]
```

### Conciliação

```dax
Posicoes OK =
CALCULATE(
    COUNTROWS(fConciliacao),
    fConciliacao[status_conciliacao] = "OK"
)

Posicoes Divergentes =
CALCULATE(
    COUNTROWS(fConciliacao),
    fConciliacao[status_conciliacao] <> "OK"
)

% Conciliação OK =
DIVIDE([Posicoes OK], COUNTROWS(fConciliacao))
```

### Time intelligence

```dax
Rentabilidade YTD =
CALCULATE(
    [Rentabilidade Dia],
    DATESYTD(dCalendario[Date])
)

Rentabilidade Mês =
CALCULATE(
    [Rentabilidade Dia],
    DATESMTD(dCalendario[Date])
)

Cota Hoje = SUM(fPLFundos[cota_hoje])

Cota Ontem = SUM(fPLFundos[cota_ontem])
```

### Enquadramento (regras dos regulamentos)

```dax
% Ações no PL =
DIVIDE(
    CALCULATE([PL Ativos], fPosicoes[tipo] = "ACAO"),
    [PL Ativos]
)

% Renda Fixa no PL =
DIVIDE(
    CALCULATE([PL Ativos], fPosicoes[tipo] = "RF"),
    [PL Ativos]
)

Status Enquadramento =
SWITCH(
    TRUE(),
    SELECTEDVALUE(dFundos[tipo_fundo]) = "Ações"
        && [% Ações no PL] >= 0.67, "✓ Enquadrado",
    SELECTEDVALUE(dFundos[tipo_fundo]) = "Renda Fixa"
        && [% Renda Fixa no PL] >= 0.80, "✓ Enquadrado",
    "✗ Verificar"
)
```

---

## 5) Estrutura das páginas do dashboard

### Página 1 — Visão Executiva (gestor / sócio)

Layout sugerido:

```
┌───────────────────────────────────────────────────────────────────┐
│ ALPHA CAPITAL — VISÃO EXECUTIVA   |   Data: [slicer dCalendario] │
├──────────────┬──────────────┬──────────────┬───────────────────── │
│ PL Total     │ Rent. Dia    │ Rent. Mês    │ Rent. YTD           │
│ R$ 49,7 mi   │ +0,12%       │ +1,8%        │ +12,4%              │
├──────────────┴──────────────┴──────────────┴──────────────────────┤
│  Gráfico de barras: PL por fundo                                   │
├────────────────────────────────────────────────────────────────────┤
│  Gráfico de linha: Evolução da cota (últimos 30 dias) por fundo    │
├────────────────────────────────────────────────────────────────────┤
│  Tabela: Fundo | PL | Cota | Rent. Dia | Rent. Mês | Rent. YTD    │
└────────────────────────────────────────────────────────────────────┘
```

**Visuais:**
- 4 cartões grandes no topo (KPIs)
- Gráfico de barras horizontais (PL por fundo)
- Gráfico de linhas (Cota Hoje por data, segmentado por fundo)
- Matriz/tabela com formatação condicional na coluna de rentabilidade (verde/vermelho)

### Página 2 — Operacional (backoffice)

```
┌───────────────────────────────────────────────────────────────────┐
│ OPERACIONAL — STATUS DAS BOLETAS                                  │
├──────────────┬──────────────┬──────────────┬──────────────────────┤
│ Boletas Hoje │ Volume       │ % Casadas    │ Divergências         │
│ 25           │ R$ 12,5 mi   │ 88%          │ 3                    │
├──────────────┴──────────────┴──────────────┴──────────────────────┤
│  Gráfico de pizza: distribuição por status (OK / Diverg / Falta) │
├────────────────────────────────────────────────────────────────────┤
│  Gráfico de barras: volume por corretora                           │
├────────────────────────────────────────────────────────────────────┤
│  Tabela detalhada: boletas com filtros por fundo, ativo, status   │
└────────────────────────────────────────────────────────────────────┘
```

### Página 3 — Risco e Enquadramento

```
┌───────────────────────────────────────────────────────────────────┐
│ ENQUADRAMENTO — % por classe de ativo                            │
├────────────────────────────────────────────────────────────────────┤
│  Gráfico empilhado 100%: composição por fundo (Ações/RF/Caixa)   │
├────────────────────────────────────────────────────────────────────┤
│  Top 10 posições (treemap por valor de mercado)                   │
├────────────────────────────────────────────────────────────────────┤
│  Concentração por emissor (barras)                                 │
├────────────────────────────────────────────────────────────────────┤
│  Tabela: enquadramento regulatório com semáforo                   │
└────────────────────────────────────────────────────────────────────┘
```

### Página 4 — Conciliação Custódia

```
┌───────────────────────────────────────────────────────────────────┐
│ CONCILIAÇÃO COM CUSTÓDIA — D-1                                    │
├──────────────┬──────────────┬──────────────────────────────────────┤
│ Posições OK  │ Divergências │ % Conciliação                       │
│ 48           │ 2            │ 96%                                  │
├──────────────┴──────────────┴──────────────────────────────────────┤
│  Tabela de divergências (filtrada por status <> OK)               │
│  Colunas: fundo, ativo, qtd_interno, qtd_custodia, diff, status   │
├────────────────────────────────────────────────────────────────────┤
│  Histórico de divergências (linha por dia)                         │
└────────────────────────────────────────────────────────────────────┘
```

---

## 6) Atualização automática

Em produção, o ideal é:

1. **Power BI Service** com **Gateway local** apontando pra pasta `output/powerbi_data/`
2. **Atualização agendada** todo dia útil às 18h (depois do Python rodar)
3. **Alertas de dados** configurados pra disparar e-mail se:
   - `Posicoes Divergentes > 5`
   - `% Conciliação OK < 95%`
   - Qualquer fundo com `Status Enquadramento = "✗ Verificar"`

---

## 7) Fluxo de dados completo

```
EXCEL/VBA          PYTHON              POWER BI
─────────          ──────              ────────
Boletas mesa  ──┐
                ├──► backoffice_alpha.py ──► powerbi_data/*.csv ──► Dashboard
Custódia      ──┤                                                    │
Preços B3     ──┘                                                    ▼
                                                              Gestores/Diretoria
```
