Attribute VB_Name = "macros_backoffice"
'==============================================================================
' MACROS DO BACKOFFICE — Alpha Capital
' Importar via Alt+F11 -> File -> Import File
' Pré-requisitos: planilha 'Backoffice_Alpha_Capital.xlsm' aberta
' Estrutura esperada de pastas (ajustar em 'Parametros'):
'   C:\Backoffice\corretoras\*.csv  *.txt
'==============================================================================

Option Explicit

' ----------------------------------------------------------------------------
' Helper: lê um parâmetro da aba Parametros
' ----------------------------------------------------------------------------
Private Function LerParametro(ByVal nome As String) As Variant
    Dim ws As Worksheet
    Dim i As Long
    Set ws = ThisWorkbook.Sheets("Parametros")
    For i = 2 To ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
        If ws.Cells(i, 1).Value = nome Then
            LerParametro = ws.Cells(i, 2).Value
            Exit Function
        End If
    Next i
    LerParametro = ""
End Function

' ----------------------------------------------------------------------------
' Helper: limpa uma aba mantendo só o cabeçalho
' ----------------------------------------------------------------------------
Private Sub LimparAba(ws As Worksheet)
    Dim ultima As Long
    ultima = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If ultima > 1 Then ws.Range("A2:Z" & ultima).Clear
End Sub

' ----------------------------------------------------------------------------
' Helper: converte string com vírgula decimal pra Double
' ----------------------------------------------------------------------------
Private Function StrParaNumero(ByVal s As String) As Double
    s = Replace(s, ".", "")  ' remove separador de milhar se houver
    s = Replace(s, ",", ".")
    If IsNumeric(s) Then
        StrParaNumero = CDbl(s)
    Else
        StrParaNumero = 0
    End If
End Function

'==============================================================================
' MACRO 1 — IMPORTAR BOLETAS DAS CORRETORAS
' Lê arquivos da pasta configurada e popula a aba Boletas_Corretoras.
' Cada corretora tem layout próprio, por isso há um Select Case.
'==============================================================================
Public Sub ImportarBoletasCorretoras()
    Dim wsDest As Worksheet
    Dim caminho As String, arquivo As String
    Dim corretora As String
    Dim linhaDest As Long
    Dim t0 As Single

    t0 = Timer
    Set wsDest = ThisWorkbook.Sheets("Boletas_Corretoras")
    LimparAba wsDest
    linhaDest = 2

    caminho = LerParametro("PASTA_CORRETORAS")
    If Right(caminho, 1) <> "\" Then caminho = caminho & "\"

    arquivo = Dir(caminho & "*.*")
    If arquivo = "" Then
        MsgBox "Nenhum arquivo encontrado em " & caminho, vbExclamation
        Exit Sub
    End If

    Application.ScreenUpdating = False

    Do While arquivo <> ""
        ' identifica corretora pelo nome do arquivo
        Select Case True
            Case InStr(UCase(arquivo), "XP_") > 0
                corretora = "XP"
                linhaDest = ImportarXP(caminho & arquivo, wsDest, linhaDest)
            Case InStr(UCase(arquivo), "BTG_") > 0
                corretora = "BTG"
                linhaDest = ImportarBTG(caminho & arquivo, wsDest, linhaDest)
            Case InStr(UCase(arquivo), "ITAU_BBA_") > 0
                corretora = "ITAU_BBA"
                linhaDest = ImportarItauBBA(caminho & arquivo, wsDest, linhaDest)
            Case InStr(UCase(arquivo), "BRADESCO_") > 0
                corretora = "BRADESCO"
                linhaDest = ImportarBradesco(caminho & arquivo, wsDest, linhaDest)
        End Select
        arquivo = Dir
    Loop

    Application.ScreenUpdating = True

    MsgBox "Importação concluída!" & vbCrLf & _
           (linhaDest - 2) & " boletas importadas em " & _
           Format(Timer - t0, "0.00") & "s.", vbInformation
End Sub

' --- Importadores específicos por corretora -------------------------------------

Private Function ImportarXP(arq As String, wsDest As Worksheet, linhaInicial As Long) As Long
    ' XP: ; ; ;  (latin-1, decimal com vírgula)
    Dim fNum As Integer, linha As String
    Dim partes() As String
    Dim ehHeader As Boolean: ehHeader = True
    Dim r As Long: r = linhaInicial

    fNum = FreeFile
    Open arq For Input As #fNum
    Do While Not EOF(fNum)
        Line Input #fNum, linha
        If ehHeader Then ehHeader = False: GoTo prox
        partes = Split(linha, ";")
        If UBound(partes) >= 7 Then
            wsDest.Cells(r, 1).Value = "XP_" & Dir(arq)
            wsDest.Cells(r, 2).Value = "XP"
            wsDest.Cells(r, 3).Value = CLng(partes(7))                ' boleta_id
            wsDest.Cells(r, 4).Value = Left(partes(0), 4) & "-" & _
                                       Mid(partes(0), 5, 2) & "-" & _
                                       Right(partes(0), 2)            ' data
            wsDest.Cells(r, 5).Value = partes(1)                       ' fundo
            wsDest.Cells(r, 6).Value = partes(2)                       ' ativo
            wsDest.Cells(r, 7).Value = partes(3)                       ' lado
            wsDest.Cells(r, 8).Value = CLng(partes(4))                 ' qtd
            wsDest.Cells(r, 9).Value = StrParaNumero(partes(5))        ' preco
            wsDest.Cells(r, 10).Value = StrParaNumero(partes(6))       ' financeiro
            r = r + 1
        End If
prox:
    Loop
    Close #fNum
    ImportarXP = r
End Function

Private Function ImportarBTG(arq As String, wsDest As Worksheet, linhaInicial As Long) As Long
    ' BTG: , , ,  (utf-8, decimal com ponto, lado em inglês)
    Dim fNum As Integer, linha As String
    Dim partes() As String
    Dim ehHeader As Boolean: ehHeader = True
    Dim r As Long: r = linhaInicial
    Dim lado As String

    fNum = FreeFile
    Open arq For Input As #fNum
    Do While Not EOF(fNum)
        Line Input #fNum, linha
        If ehHeader Then ehHeader = False: GoTo prox
        partes = Split(linha, ",")
        If UBound(partes) >= 7 Then
            lado = IIf(UCase(partes(3)) = "BUY", "C", "V")
            wsDest.Cells(r, 1).Value = "BTG_" & Dir(arq)
            wsDest.Cells(r, 2).Value = "BTG"
            wsDest.Cells(r, 3).Value = CLng(partes(7))
            wsDest.Cells(r, 4).Value = partes(0)
            wsDest.Cells(r, 5).Value = partes(1)
            wsDest.Cells(r, 6).Value = partes(2)
            wsDest.Cells(r, 7).Value = lado
            wsDest.Cells(r, 8).Value = CLng(partes(4))
            wsDest.Cells(r, 9).Value = CDbl(partes(5))
            wsDest.Cells(r, 10).Value = CDbl(partes(6))
            r = r + 1
        End If
prox:
    Loop
    Close #fNum
    ImportarBTG = r
End Function

Private Function ImportarItauBBA(arq As String, wsDest As Worksheet, linhaInicial As Long) As Long
    ' Itaú BBA: pipe-separated (|)
    Dim fNum As Integer, linha As String
    Dim partes() As String
    Dim ehHeader As Boolean: ehHeader = True
    Dim r As Long: r = linhaInicial

    fNum = FreeFile
    Open arq For Input As #fNum
    Do While Not EOF(fNum)
        Line Input #fNum, linha
        If ehHeader Then ehHeader = False: GoTo prox
        partes = Split(linha, "|")
        If UBound(partes) >= 7 Then
            wsDest.Cells(r, 1).Value = "ITAU_" & Dir(arq)
            wsDest.Cells(r, 2).Value = "ITAU_BBA"
            wsDest.Cells(r, 3).Value = CLng(partes(7))
            wsDest.Cells(r, 4).Value = partes(0)
            wsDest.Cells(r, 5).Value = partes(1)
            wsDest.Cells(r, 6).Value = partes(2)
            wsDest.Cells(r, 7).Value = partes(3)
            wsDest.Cells(r, 8).Value = CLng(partes(4))
            wsDest.Cells(r, 9).Value = CDbl(partes(5))
            wsDest.Cells(r, 10).Value = CDbl(partes(6))
            r = r + 1
        End If
prox:
    Loop
    Close #fNum
    ImportarItauBBA = r
End Function

Private Function ImportarBradesco(arq As String, wsDest As Worksheet, linhaInicial As Long) As Long
    ' Bradesco: ; ; com 'Compra'/'Venda' por extenso
    Dim fNum As Integer, linha As String
    Dim partes() As String
    Dim ehHeader As Boolean: ehHeader = True
    Dim r As Long: r = linhaInicial
    Dim lado As String

    fNum = FreeFile
    Open arq For Input As #fNum
    Do While Not EOF(fNum)
        Line Input #fNum, linha
        If ehHeader Then ehHeader = False: GoTo prox
        partes = Split(linha, ";")
        If UBound(partes) >= 7 Then
            lado = IIf(UCase(partes(3)) = "COMPRA", "C", "V")
            wsDest.Cells(r, 1).Value = "BRAD_" & Dir(arq)
            wsDest.Cells(r, 2).Value = "BRADESCO"
            wsDest.Cells(r, 3).Value = CLng(partes(7))
            wsDest.Cells(r, 4).Value = partes(0)
            wsDest.Cells(r, 5).Value = partes(1)
            wsDest.Cells(r, 6).Value = partes(2)
            wsDest.Cells(r, 7).Value = lado
            wsDest.Cells(r, 8).Value = CLng(partes(4))
            wsDest.Cells(r, 9).Value = StrParaNumero(partes(5))
            wsDest.Cells(r, 10).Value = StrParaNumero(partes(6))
            r = r + 1
        End If
prox:
    Loop
    Close #fNum
    ImportarBradesco = r
End Function

'==============================================================================
' MACRO 2 — CASAR OPERAÇÕES (mesa x corretoras)
' Compara cada boleta da mesa com a correspondente da corretora pelo boleta_id.
' Marca status: OK / DIVERGENTE / FALTA_CORRETORA / FALTA_MESA
'==============================================================================
Public Sub CasarOperacoes()
    Dim wsMesa As Worksheet, wsCorr As Worksheet, wsCas As Worksheet
    Dim ultMesa As Long, ultCorr As Long, r As Long, i As Long, j As Long
    Dim tolPreco As Double, tolQtd As Double
    Dim achou As Boolean
    Dim qtdM As Long, qtdC As Long
    Dim prM As Double, prC As Double, diffPct As Double
    Dim status As String, obs As String

    Set wsMesa = ThisWorkbook.Sheets("Boletas_Mesa")
    Set wsCorr = ThisWorkbook.Sheets("Boletas_Corretoras")
    Set wsCas = ThisWorkbook.Sheets("Casamento")

    LimparAba wsCas

    tolPreco = LerParametro("TOLERANCIA_PRECO")
    tolQtd = LerParametro("TOLERANCIA_QTD")

    ultMesa = wsMesa.Cells(wsMesa.Rows.Count, 1).End(xlUp).Row
    ultCorr = wsCorr.Cells(wsCorr.Rows.Count, 1).End(xlUp).Row
    r = 2

    Application.ScreenUpdating = False

    ' Para cada boleta da mesa, procurar a correspondente
    For i = 2 To ultMesa
        achou = False
        qtdM = wsMesa.Cells(i, 6).Value
        prM = wsMesa.Cells(i, 7).Value
        For j = 2 To ultCorr
            If wsMesa.Cells(i, 1).Value = wsCorr.Cells(j, 3).Value Then  ' boleta_id
                achou = True
                qtdC = wsCorr.Cells(j, 8).Value
                prC = wsCorr.Cells(j, 9).Value
                diffPct = IIf(prM = 0, 0, (prC - prM) / prM)

                If Abs(qtdM - qtdC) <= tolQtd And Abs(diffPct) <= tolPreco Then
                    status = "OK"
                    obs = ""
                Else
                    status = "DIVERGENTE"
                    obs = ""
                    If Abs(qtdM - qtdC) > tolQtd Then obs = obs & "qtd; "
                    If Abs(diffPct) > tolPreco Then obs = obs & "preco; "
                End If

                EscreverLinhaCasamento wsCas, r, wsMesa.Cells(i, 1).Value, _
                    wsMesa.Cells(i, 3).Value, wsMesa.Cells(i, 4).Value, _
                    wsMesa.Cells(i, 5).Value, qtdM, qtdC, prM, prC, _
                    qtdM - qtdC, diffPct, status, obs
                r = r + 1
                Exit For
            End If
        Next j

        If Not achou Then
            EscreverLinhaCasamento wsCas, r, wsMesa.Cells(i, 1).Value, _
                wsMesa.Cells(i, 3).Value, wsMesa.Cells(i, 4).Value, _
                wsMesa.Cells(i, 5).Value, qtdM, 0, prM, 0, qtdM, 0, _
                "FALTA_CORRETORA", "boleta da mesa sem correspondente"
            r = r + 1
        End If
    Next i

    ' Boletas que estão na corretora mas não na mesa
    For j = 2 To ultCorr
        achou = False
        For i = 2 To ultMesa
            If wsCorr.Cells(j, 3).Value = wsMesa.Cells(i, 1).Value Then
                achou = True
                Exit For
            End If
        Next i
        If Not achou Then
            EscreverLinhaCasamento wsCas, r, wsCorr.Cells(j, 3).Value, _
                wsCorr.Cells(j, 5).Value, wsCorr.Cells(j, 6).Value, _
                wsCorr.Cells(j, 7).Value, 0, wsCorr.Cells(j, 8).Value, _
                0, wsCorr.Cells(j, 9).Value, -wsCorr.Cells(j, 8).Value, 0, _
                "FALTA_MESA", "boleta da corretora sem correspondente"
            r = r + 1
        End If
    Next j

    PintarCasamento wsCas, r - 1
    Application.ScreenUpdating = True

    MsgBox "Casamento concluído. " & (r - 2) & " linhas processadas.", vbInformation
End Sub

Private Sub EscreverLinhaCasamento(ws As Worksheet, r As Long, _
        boletaId As Long, fundo As String, ativo As String, lado As String, _
        qtdM As Long, qtdC As Long, prM As Double, prC As Double, _
        diffQtd As Long, diffPct As Double, status As String, obs As String)
    ws.Cells(r, 1).Value = boletaId
    ws.Cells(r, 2).Value = fundo
    ws.Cells(r, 3).Value = ativo
    ws.Cells(r, 4).Value = lado
    ws.Cells(r, 5).Value = qtdM
    ws.Cells(r, 6).Value = qtdC
    ws.Cells(r, 7).Value = prM
    ws.Cells(r, 8).Value = prC
    ws.Cells(r, 9).Value = diffQtd
    ws.Cells(r, 10).Value = diffPct
    ws.Cells(r, 10).NumberFormat = "0.0000%"
    ws.Cells(r, 11).Value = status
    ws.Cells(r, 12).Value = obs
End Sub

Private Sub PintarCasamento(ws As Worksheet, ultLinha As Long)
    Dim i As Long, st As String
    For i = 2 To ultLinha
        st = ws.Cells(i, 11).Value
        Select Case st
            Case "OK"
                ws.Range(ws.Cells(i, 1), ws.Cells(i, 12)).Interior.Color = RGB(198, 239, 206)
            Case "DIVERGENTE"
                ws.Range(ws.Cells(i, 1), ws.Cells(i, 12)).Interior.Color = RGB(255, 199, 206)
            Case "FALTA_CORRETORA", "FALTA_MESA"
                ws.Range(ws.Cells(i, 1), ws.Cells(i, 12)).Interior.Color = RGB(255, 235, 156)
        End Select
    Next i
End Sub

'==============================================================================
' MACRO 3 — GERAR NECESSIDADE DE CAIXA
' Agrupa boletas por fundo + data de liquidação. Compras saem caixa,
' vendas entram. Saldo líquido < 0 = precisa providenciar caixa.
'==============================================================================
Public Sub GerarNecessidadeCaixa()
    Dim wsMesa As Worksheet, wsCx As Worksheet
    Dim ult As Long, i As Long, r As Long
    Dim chave As String
    Dim dict As Object
    Dim fundo As String, dt As String, lado As String
    Dim valor As Double

    Set wsMesa = ThisWorkbook.Sheets("Boletas_Mesa")
    Set wsCx = ThisWorkbook.Sheets("Necessidade_Caixa")
    Set dict = CreateObject("Scripting.Dictionary")

    LimparAba wsCx

    ult = wsMesa.Cells(wsMesa.Rows.Count, 1).End(xlUp).Row

    For i = 2 To ult
        fundo = wsMesa.Cells(i, 3).Value
        dt = CStr(wsMesa.Cells(i, 11).Value)
        lado = wsMesa.Cells(i, 5).Value
        valor = wsMesa.Cells(i, 8).Value
        chave = fundo & "|" & dt
        If Not dict.Exists(chave) Then dict.Add chave, Array(0, 0)
        Dim arr As Variant: arr = dict(chave)
        If lado = "C" Then
            arr(0) = arr(0) + valor
        Else
            arr(1) = arr(1) + valor
        End If
        dict(chave) = arr
    Next i

    r = 2
    Dim k As Variant
    For Each k In dict.Keys
        Dim p() As String: p = Split(CStr(k), "|")
        Dim arr2 As Variant: arr2 = dict(k)
        wsCx.Cells(r, 1).Value = p(0)
        wsCx.Cells(r, 2).Value = p(1)
        wsCx.Cells(r, 3).Value = arr2(0)
        wsCx.Cells(r, 4).Value = arr2(1)
        wsCx.Cells(r, 5).Value = arr2(1) - arr2(0)  ' vendas - compras
        wsCx.Cells(r, 6).Value = IIf(arr2(1) - arr2(0) < 0, "SHORTFALL", "OK")
        If wsCx.Cells(r, 6).Value = "SHORTFALL" Then
            wsCx.Range(wsCx.Cells(r, 1), wsCx.Cells(r, 6)).Interior.Color = RGB(255, 199, 206)
        End If
        wsCx.Cells(r, 3).NumberFormat = "#,##0.00"
        wsCx.Cells(r, 4).NumberFormat = "#,##0.00"
        wsCx.Cells(r, 5).NumberFormat = "#,##0.00"
        r = r + 1
    Next k

    MsgBox "Necessidade de caixa calculada para " & (r - 2) & " combinações fundo/data.", vbInformation
End Sub

'==============================================================================
' MACRO 4 — ATUALIZAR TUDO
'==============================================================================
Public Sub AtualizarTudo()
    Application.DisplayAlerts = False
    ImportarBoletasCorretoras
    CasarOperacoes
    GerarNecessidadeCaixa
    Application.DisplayAlerts = True
    MsgBox "Pipeline completo executado!", vbInformation
End Sub
