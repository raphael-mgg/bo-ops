"""
Gera o Excel mestre 'Backoffice_Alpha_Capital.xlsm' com:
- aba Boletas_Mesa
- aba Boletas_Corretoras
- aba Casamento (resultado)
- aba Necessidade_Caixa
- aba Parametros
- aba Instrucoes (com o código VBA documentado pra você copiar/colar)

Como openpyxl não consegue salvar .xlsm com VBA embutido sem um template
binário, geramos um .xlsx funcional + um arquivo .bas com as macros prontas
pra serem importadas no Excel via Alt+F11 → File → Import File.
"""
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule
import csv

BASE = Path(__file__).resolve().parent.parent
OUT = BASE / "output"

# ============================================================
# Estilos
# ============================================================
HEADER_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
HEADER_FILL = PatternFill("solid", start_color="1F3864")
HEADER_ALIGN = Alignment(horizontal="center", vertical="center")

NORMAL_FONT = Font(name="Arial", size=10)
NORMAL_ALIGN = Alignment(horizontal="left", vertical="center")
NUM_ALIGN = Alignment(horizontal="right", vertical="center")

BORDER = Border(
    left=Side(style="thin", color="CCCCCC"),
    right=Side(style="thin", color="CCCCCC"),
    top=Side(style="thin", color="CCCCCC"),
    bottom=Side(style="thin", color="CCCCCC"),
)

OK_FILL = PatternFill("solid", start_color="C6EFCE")
DIVERG_FILL = PatternFill("solid", start_color="FFC7CE")
PEND_FILL = PatternFill("solid", start_color="FFEB9C")


def estilizar_header(ws, n_cols):
    for col in range(1, n_cols + 1):
        c = ws.cell(row=1, column=col)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = HEADER_ALIGN
        c.border = BORDER
    ws.row_dimensions[1].height = 22
    ws.freeze_panes = "A2"


def autoajustar(ws):
    for col in ws.columns:
        max_len = 0
        letter = col[0].column_letter
        for cell in col:
            v = "" if cell.value is None else str(cell.value)
            if len(v) > max_len:
                max_len = len(v)
        ws.column_dimensions[letter].width = min(max_len + 3, 28)


# ============================================================
# Cria o workbook
# ============================================================
wb = Workbook()

# ---------- Aba Instrucoes ----------
ws_inst = wb.active
ws_inst.title = "Instrucoes"
ws_inst["A1"] = "BACKOFFICE ALPHA CAPITAL — Manual da Planilha"
ws_inst["A1"].font = Font(name="Arial", size=14, bold=True, color="1F3864")

instrucoes = [
    "",
    "ABAS DESTA PLANILHA:",
    "  • Boletas_Mesa: operações registradas pela mesa de gestão (entrada manual ou copy/paste do OMS)",
    "  • Boletas_Corretoras: operações importadas dos arquivos das corretoras (preenchida pela macro)",
    "  • Casamento: resultado do batimento mesa x corretora (preenchida pela macro)",
    "  • Necessidade_Caixa: cálculo de caixa por fundo/data de liquidação",
    "  • Parametros: caminhos e configurações",
    "",
    "MACROS DISPONÍVEIS (Alt+F8 ou botões na aba):",
    "  1) ImportarBoletasCorretoras  — lê os arquivos da pasta ./corretoras/ e popula Boletas_Corretoras",
    "  2) CasarOperacoes             — cruza Boletas_Mesa x Boletas_Corretoras e gera o Casamento",
    "  3) GerarNecessidadeCaixa      — agrega valor financeiro por fundo e data de liquidação",
    "  4) AtualizarTudo              — executa as 3 acima em sequência",
    "",
    "COMO INSTALAR AS MACROS:",
    "  1. Abra este arquivo no Excel",
    "  2. Pressione Alt+F11 (abre o editor VBA)",
    "  3. Menu File → Import File → selecione 'macros_backoffice.bas'",
    "  4. Salve como .xlsm (Pasta de Trabalho Habilitada para Macro)",
    "  5. Volte ao Excel e pressione Alt+F8 para ver as macros",
    "",
    "FLUXO DIÁRIO TÍPICO:",
    "  08:00 → Cole as boletas da mesa em Boletas_Mesa (ou já vem do sistema)",
    "  08:30 → Rode 'AtualizarTudo' — importa corretoras, casa e calcula caixa",
    "  09:00 → Trate divergências (linhas vermelhas em Casamento)",
    "  10:00 → Confira aba Necessidade_Caixa e avise gestor se houver shortfall",
    "  14:00 → Rode o script Python de conciliação com custódia",
    "  17:00 → Atualize o Power BI",
    "  18:00 → Fechamento e backup",
]
for i, txt in enumerate(instrucoes, start=2):
    ws_inst.cell(row=i, column=1, value=txt).font = Font(name="Arial", size=10)
ws_inst.column_dimensions["A"].width = 110


# ---------- Aba Parametros ----------
ws_par = wb.create_sheet("Parametros")
ws_par["A1"] = "Parâmetro"
ws_par["B1"] = "Valor"
ws_par["C1"] = "Descrição"
estilizar_header(ws_par, 3)
parametros = [
    ("PASTA_CORRETORAS", "C:\\Backoffice\\corretoras\\", "Caminho onde estão os arquivos das corretoras"),
    ("DATA_PREGAO", "2026-04-28", "Data D0 da operação"),
    ("TOLERANCIA_PRECO", 0.001, "Tolerância de preço pra considerar OK (0,1%)"),
    ("TOLERANCIA_QTD", 0, "Tolerância absoluta de quantidade"),
]
for i, (p, v, d) in enumerate(parametros, start=2):
    ws_par.cell(row=i, column=1, value=p).font = NORMAL_FONT
    ws_par.cell(row=i, column=2, value=v).font = NORMAL_FONT
    ws_par.cell(row=i, column=3, value=d).font = NORMAL_FONT
autoajustar(ws_par)


# ---------- Aba Boletas_Mesa ----------
ws_mesa = wb.create_sheet("Boletas_Mesa")
headers_mesa = ["boleta_id", "data_operacao", "fundo", "ativo", "lado",
                "quantidade", "preco", "valor_financeiro", "corretora",
                "liquidacao", "data_liquidacao"]
for c, h in enumerate(headers_mesa, start=1):
    ws_mesa.cell(row=1, column=c, value=h)
estilizar_header(ws_mesa, len(headers_mesa))

# popula com boletas geradas
with open(BASE / "dados" / "boletas_mesa.csv", encoding="utf-8") as f:
    reader = csv.DictReader(f, delimiter=";")
    for r_idx, row in enumerate(reader, start=2):
        for c_idx, h in enumerate(headers_mesa, start=1):
            val = row[h]
            # converter números
            if h in ("boleta_id", "quantidade"):
                val = int(val)
            elif h in ("preco", "valor_financeiro"):
                val = float(val)
            cell = ws_mesa.cell(row=r_idx, column=c_idx, value=val)
            cell.font = NORMAL_FONT
            if h in ("preco", "valor_financeiro", "quantidade"):
                cell.alignment = NUM_ALIGN
                if h == "preco":
                    cell.number_format = "#,##0.0000"
                elif h == "valor_financeiro":
                    cell.number_format = '"R$ "#,##0.00'
                else:
                    cell.number_format = "#,##0"
autoajustar(ws_mesa)

# ---------- Aba Boletas_Corretoras (vazia, será preenchida pela macro) ----------
ws_corr = wb.create_sheet("Boletas_Corretoras")
headers_corr = ["arquivo_origem", "corretora", "boleta_id", "data_operacao",
                "fundo", "ativo", "lado", "quantidade", "preco", "valor_financeiro"]
for c, h in enumerate(headers_corr, start=1):
    ws_corr.cell(row=1, column=c, value=h)
estilizar_header(ws_corr, len(headers_corr))
ws_corr.cell(row=2, column=1, value="(rode 'ImportarBoletasCorretoras' para preencher)").font = Font(
    name="Arial", size=10, italic=True, color="888888"
)
autoajustar(ws_corr)

# ---------- Aba Casamento ----------
ws_cas = wb.create_sheet("Casamento")
headers_cas = ["boleta_id", "fundo", "ativo", "lado", "qtd_mesa", "qtd_corretora",
               "preco_mesa", "preco_corretora", "diff_qtd", "diff_preco_pct",
               "status", "observacao"]
for c, h in enumerate(headers_cas, start=1):
    ws_cas.cell(row=1, column=c, value=h)
estilizar_header(ws_cas, len(headers_cas))
ws_cas.cell(row=2, column=1, value="(rode 'CasarOperacoes' para preencher)").font = Font(
    name="Arial", size=10, italic=True, color="888888"
)
autoajustar(ws_cas)

# ---------- Aba Necessidade_Caixa ----------
ws_cx = wb.create_sheet("Necessidade_Caixa")
headers_cx = ["fundo", "data_liquidacao", "compras", "vendas", "saldo_liquido", "alerta"]
for c, h in enumerate(headers_cx, start=1):
    ws_cx.cell(row=1, column=c, value=h)
estilizar_header(ws_cx, len(headers_cx))
ws_cx.cell(row=2, column=1, value="(rode 'GerarNecessidadeCaixa' para preencher)").font = Font(
    name="Arial", size=10, italic=True, color="888888"
)
autoajustar(ws_cx)

# salvar
OUT.mkdir(exist_ok=True)
out_xlsx = OUT / "Backoffice_Alpha_Capital.xlsx"
wb.save(out_xlsx)
print(f">>> Excel mestre salvo: {out_xlsx}")
