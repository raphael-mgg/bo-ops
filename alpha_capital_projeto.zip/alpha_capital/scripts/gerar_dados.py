"""
Gerador de dados sintéticos para simular o ambiente de backoffice
da gestora Alpha Capital.

Produz:
- boletas_mesa.csv (operações registradas pela mesa)
- corretoras/*.csv (arquivos enviados pelas corretoras, layouts diferentes)
- custodia/posicao_custodia.csv (posição oficial enviada pelo custodiante)
- precos/precos_b3.csv (preços de fechamento)
- dados/posicao_inicial.csv (posição da gestora no D-1)
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)

BASE = Path(__file__).resolve().parent.parent
DATA_PREGAO = date(2026, 4, 28)  # D0 da operação

# ----------------------------------------------------------------------
# Universo de ativos e fundos
# ----------------------------------------------------------------------
FUNDOS = [
    "ALPHA_ACOES_FIA",
    "ALPHA_MULTIMERCADO_FIM",
    "ALPHA_RF_FIRF",
    "ALPHA_DIVIDENDOS_FIA",
    "ALPHA_LONG_BIAS_FIM",
]

ACOES = {
    "PETR4": 38.45, "VALE3": 67.20, "ITUB4": 34.10, "BBDC4": 16.85,
    "ABEV3": 13.40, "WEGE3": 41.55, "BBAS3": 28.70, "B3SA3": 12.30,
    "MGLU3":  8.95, "RENT3": 56.40, "SUZB3": 52.10, "ELET3": 38.90,
}

RENDA_FIXA = {
    "LFT_2029": 14250.30,    # preço unitário
    "NTNB_2035": 4180.75,
    "CDB_BTG_2027": 1052.40,
    "DEB_VALE_2030": 1108.90,
}

ATIVOS = {**ACOES, **RENDA_FIXA}
TIPO_ATIVO = {t: ("ACAO" if t in ACOES else "RF") for t in ATIVOS}

CORRETORAS = ["XP", "BTG", "ITAU_BBA", "BRADESCO"]


# ----------------------------------------------------------------------
# 1) Posição inicial (D-1) — o que a gestora tinha em carteira ontem
# ----------------------------------------------------------------------
def gerar_posicao_inicial():
    rows = []
    bid = 1
    for fundo in FUNDOS:
        # cada fundo tem entre 5 e 9 posições
        ativos_fundo = random.sample(list(ATIVOS.keys()), k=random.randint(5, 9))
        for ativo in ativos_fundo:
            qtd = random.choice([1000, 2000, 5000, 10000, 20000, 50000])
            if TIPO_ATIVO[ativo] == "RF":
                qtd = random.choice([10, 50, 100, 500])
            rows.append({
                "fundo": fundo,
                "ativo": ativo,
                "tipo": TIPO_ATIVO[ativo],
                "quantidade": qtd,
                "preco_medio": round(ATIVOS[ativo] * random.uniform(0.85, 1.05), 2),
            })
            bid += 1

    path = BASE / "dados" / "posicao_inicial.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys(), delimiter=";")
        w.writeheader()
        w.writerows(rows)
    return rows


# ----------------------------------------------------------------------
# 2) Boletas da mesa — o que o gestor disse que operou
# ----------------------------------------------------------------------
def gerar_boletas_mesa():
    boletas = []
    boleta_id = 10001
    # ~25 operações no dia distribuídas entre fundos
    for _ in range(25):
        fundo = random.choice(FUNDOS)
        ativo = random.choice(list(ATIVOS.keys()))
        lado = random.choice(["C", "V"])  # Compra / Venda
        if TIPO_ATIVO[ativo] == "ACAO":
            qtd = random.choice([100, 200, 500, 1000, 2000, 5000])
            liquidacao = "D+2"
        else:
            qtd = random.choice([5, 10, 25, 50])
            liquidacao = "D+1" if "LFT" in ativo or "NTNB" in ativo else "D+0"
        preco = round(ATIVOS[ativo] * random.uniform(0.985, 1.015), 2)
        corretora = random.choice(CORRETORAS)
        boletas.append({
            "boleta_id": boleta_id,
            "data_operacao": DATA_PREGAO.isoformat(),
            "fundo": fundo,
            "ativo": ativo,
            "lado": lado,
            "quantidade": qtd,
            "preco": preco,
            "valor_financeiro": round(qtd * preco, 2),
            "corretora": corretora,
            "liquidacao": liquidacao,
            "data_liquidacao": (DATA_PREGAO + timedelta(days={"D+0":0,"D+1":1,"D+2":2}[liquidacao])).isoformat(),
        })
        boleta_id += 1

    path = BASE / "dados" / "boletas_mesa.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=boletas[0].keys(), delimiter=";")
        w.writeheader()
        w.writerows(boletas)
    return boletas


# ----------------------------------------------------------------------
# 3) Arquivos das corretoras — UM LAYOUT DIFERENTE PRA CADA UMA
#    (essa é a dor real do backoffice: padronizar isso)
#    Vamos introduzir DE PROPÓSITO algumas divergências.
# ----------------------------------------------------------------------
def gerar_arquivos_corretoras(boletas):
    # introduzir 3 divergências propositais:
    # - 1 boleta com preço ligeiramente diferente
    # - 1 boleta com quantidade diferente
    # - 1 boleta que não aparece na corretora (esquecida)
    boletas_corr = [dict(b) for b in boletas]
    random.shuffle(boletas_corr)

    if len(boletas_corr) >= 3:
        # divergência de preço
        boletas_corr[0]["preco"] = round(boletas_corr[0]["preco"] + 0.05, 2)
        boletas_corr[0]["valor_financeiro"] = round(
            boletas_corr[0]["quantidade"] * boletas_corr[0]["preco"], 2
        )
        # divergência de quantidade
        boletas_corr[1]["quantidade"] = boletas_corr[1]["quantidade"] + 100
        boletas_corr[1]["valor_financeiro"] = round(
            boletas_corr[1]["quantidade"] * boletas_corr[1]["preco"], 2
        )
        # remover 1 boleta (corretora não enviou)
        boletas_corr.pop(2)

    # XP — CSV ; encoding latin-1, colunas em maiúsculo
    xp = [b for b in boletas_corr if b["corretora"] == "XP"]
    with open(BASE / "corretoras" / "XP_boletas_20260428.csv", "w",
              newline="", encoding="latin-1") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["DT_NEGOCIO", "COD_CLIENTE", "TICKER", "C_V", "QTDE", "PRECO", "VL_FINANCEIRO", "ID_BOLETA"])
        for b in xp:
            w.writerow([
                b["data_operacao"].replace("-", ""),
                b["fundo"],
                b["ativo"],
                b["lado"],
                b["quantidade"],
                f'{b["preco"]:.2f}'.replace(".", ","),
                f'{b["valor_financeiro"]:.2f}'.replace(".", ","),
                b["boleta_id"],
            ])

    # BTG — CSV , encoding utf-8, colunas em inglês
    btg = [b for b in boletas_corr if b["corretora"] == "BTG"]
    with open(BASE / "corretoras" / "BTG_trades_20260428.csv", "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=",")
        w.writerow(["trade_date", "account", "symbol", "side", "quantity", "price", "notional", "trade_id"])
        for b in btg:
            w.writerow([
                b["data_operacao"],
                b["fundo"],
                b["ativo"],
                "BUY" if b["lado"] == "C" else "SELL",
                b["quantidade"],
                f'{b["preco"]:.4f}',
                f'{b["valor_financeiro"]:.2f}',
                b["boleta_id"],
            ])

    # ITAU_BBA — TXT pipe-separated
    itau = [b for b in boletas_corr if b["corretora"] == "ITAU_BBA"]
    with open(BASE / "corretoras" / "ITAU_BBA_op_20260428.txt", "w",
              encoding="utf-8") as f:
        f.write("DATA|FUNDO|PAPEL|OPER|QUANT|PU|FINANCEIRO|NUM_BOLETA\n")
        for b in itau:
            f.write(
                f'{b["data_operacao"]}|{b["fundo"]}|{b["ativo"]}|{b["lado"]}|'
                f'{b["quantidade"]}|{b["preco"]:.2f}|{b["valor_financeiro"]:.2f}|'
                f'{b["boleta_id"]}\n'
            )

    # BRADESCO — CSV ; com cabeçalho "feio"
    brad = [b for b in boletas_corr if b["corretora"] == "BRADESCO"]
    with open(BASE / "corretoras" / "BRADESCO_corretora_20260428.csv", "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Dt. Pregão", "Cód. Cliente", "Cód. Ativo", "Compra/Venda",
                    "Quantidade", "Preço Unitário", "Valor Total", "Boleta"])
        for b in brad:
            w.writerow([
                b["data_operacao"],
                b["fundo"],
                b["ativo"],
                "Compra" if b["lado"] == "C" else "Venda",
                b["quantidade"],
                f'{b["preco"]:.2f}'.replace(".", ","),
                f'{b["valor_financeiro"]:.2f}'.replace(".", ","),
                b["boleta_id"],
            ])

    return boletas_corr


# ----------------------------------------------------------------------
# 4) Posição da custódia — também com algumas divergências propositais
# ----------------------------------------------------------------------
def gerar_posicao_custodia(posicao_inicial, boletas):
    # calcula posição esperada após boletas (D0) — a gestora "acredita"
    pos = {}
    for p in posicao_inicial:
        pos[(p["fundo"], p["ativo"])] = {
            "fundo": p["fundo"],
            "ativo": p["ativo"],
            "quantidade": p["quantidade"],
        }
    for b in boletas:
        chave = (b["fundo"], b["ativo"])
        if chave not in pos:
            pos[chave] = {"fundo": b["fundo"], "ativo": b["ativo"], "quantidade": 0}
        delta = b["quantidade"] if b["lado"] == "C" else -b["quantidade"]
        pos[chave]["quantidade"] += delta

    custodia = [v for v in pos.values() if v["quantidade"] != 0]

    # introduzir divergências:
    # - 1 ativo com qtd levemente diferente (evento corporativo não tratado)
    # - 1 ativo na custódia que não está no controle (recebido por bonificação)
    if custodia:
        custodia[0]["quantidade"] += 50
        custodia.append({
            "fundo": "ALPHA_ACOES_FIA",
            "ativo": "VALE3",
            "quantidade": 200,  # bonificação fictícia
        })

    path = BASE / "custodia" / "posicao_custodia_20260428.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["DATA_POSICAO", "CD_FUNDO", "CD_ATIVO", "QTD_CUSTODIA"])
        for c in custodia:
            w.writerow([DATA_PREGAO.isoformat(), c["fundo"], c["ativo"], c["quantidade"]])

    return custodia


# ----------------------------------------------------------------------
# 5) Preços de fechamento da B3 (pra marcação a mercado)
# ----------------------------------------------------------------------
def gerar_precos():
    path = BASE / "precos" / "precos_b3_20260428.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["data", "ativo", "preco_fechamento"])
        for ativo, preco in ATIVOS.items():
            # preço de fechamento varia ±2% do "preço base"
            fechamento = round(preco * random.uniform(0.98, 1.02), 2)
            w.writerow([DATA_PREGAO.isoformat(), ativo, fechamento])


# ----------------------------------------------------------------------
if __name__ == "__main__":
    print(">>> Gerando dados sintéticos da Alpha Capital...")
    pos_inicial = gerar_posicao_inicial()
    boletas = gerar_boletas_mesa()
    gerar_arquivos_corretoras(boletas)
    gerar_posicao_custodia(pos_inicial, boletas)
    gerar_precos()
    print(f">>> {len(pos_inicial)} posições iniciais")
    print(f">>> {len(boletas)} boletas da mesa")
    print(">>> Arquivos das corretoras gerados em ./corretoras/")
    print(">>> Posição da custódia em ./custodia/")
    print(">>> Preços em ./precos/")
    print(">>> OK")
