"""
backoffice_alpha.py
====================
Script único que executa as rotinas pesadas do backoffice da Alpha Capital:

1) CONCILIAÇÃO DE CUSTÓDIA
   Compara a posição interna (calculada a partir de posicao_inicial + boletas)
   com a posição enviada pela custódia. Gera arquivo de divergências.

2) MARCAÇÃO A MERCADO
   Aplica preços de fechamento da B3 (e PUs de RF) sobre as posições
   pra calcular o valor de mercado por ativo, fundo e o PL total.

3) CÁLCULO DE COTA E P&L DIÁRIO
   Compara PL atual com PL anterior pra gerar a rentabilidade do dia.

4) EXPORT PARA POWER BI
   Salva tudo em formato tidy (long format) num único Excel com várias abas
   e também em CSV pra ser consumido pelo Power BI.

Uso:
    python backoffice_alpha.py
"""
from __future__ import annotations
from pathlib import Path
from datetime import date
import pandas as pd
import numpy as np

BASE = Path(__file__).resolve().parent.parent
DATA_PREGAO = "2026-04-28"

# Cota anterior por fundo (D-1) — em produção viria do banco/Excel histórico
COTA_ANTERIOR = {
    "ALPHA_ACOES_FIA":         3.521840,
    "ALPHA_MULTIMERCADO_FIM":  2.184750,
    "ALPHA_RF_FIRF":           1.872310,
    "ALPHA_DIVIDENDOS_FIA":    4.105260,
    "ALPHA_LONG_BIAS_FIM":     1.952170,
}

# Caixa por fundo no início do dia (D-1) — também viria do banco
CAIXA_INICIAL = {
    "ALPHA_ACOES_FIA":         5_000_000.00,
    "ALPHA_MULTIMERCADO_FIM":  8_500_000.00,
    "ALPHA_RF_FIRF":           3_200_000.00,
    "ALPHA_DIVIDENDOS_FIA":    2_800_000.00,
    "ALPHA_LONG_BIAS_FIM":    12_000_000.00,
}

# Cotas em circulação (qtd de cotas) — viria da escrituradora
COTAS_CIRCULACAO = {
    "ALPHA_ACOES_FIA":         42_580_000,
    "ALPHA_MULTIMERCADO_FIM":  61_200_000,
    "ALPHA_RF_FIRF":           38_900_000,
    "ALPHA_DIVIDENDOS_FIA":    18_750_000,
    "ALPHA_LONG_BIAS_FIM":     95_400_000,
}


# ============================================================================
# 1) CARGA DOS DADOS
# ============================================================================
def carregar_dados() -> dict[str, pd.DataFrame]:
    print("[1/4] Carregando dados...")
    pos_ini = pd.read_csv(BASE / "dados" / "posicao_inicial.csv", sep=";")
    boletas = pd.read_csv(BASE / "dados" / "boletas_mesa.csv", sep=";")
    custodia = pd.read_csv(BASE / "custodia" / "posicao_custodia_20260428.csv", sep=";")
    precos = pd.read_csv(BASE / "precos" / "precos_b3_20260428.csv", sep=";")

    # padronização
    custodia = custodia.rename(columns={
        "CD_FUNDO": "fundo", "CD_ATIVO": "ativo", "QTD_CUSTODIA": "qtd_custodia"
    })

    print(f"      ✓ Posição inicial: {len(pos_ini)} linhas")
    print(f"      ✓ Boletas mesa: {len(boletas)} linhas")
    print(f"      ✓ Custódia: {len(custodia)} linhas")
    print(f"      ✓ Preços: {len(precos)} ativos")

    return {
        "pos_inicial": pos_ini,
        "boletas": boletas,
        "custodia": custodia,
        "precos": precos,
    }


# ============================================================================
# 2) POSIÇÃO INTERNA APÓS BOLETAS (D0)
# ============================================================================
def calcular_posicao_interna(pos_inicial: pd.DataFrame,
                             boletas: pd.DataFrame) -> pd.DataFrame:
    """
    Aplica as boletas (compras +, vendas -) sobre a posição inicial
    pra obter a posição interna no fim do dia.
    """
    # Movimentações por boleta
    mov = boletas.copy()
    mov["delta_qtd"] = np.where(mov["lado"] == "C",
                                mov["quantidade"], -mov["quantidade"])
    mov["delta_financeiro"] = np.where(mov["lado"] == "C",
                                       -mov["valor_financeiro"],
                                        mov["valor_financeiro"])

    # Agrega movimentações por fundo+ativo
    mov_agg = (mov.groupby(["fundo", "ativo"], as_index=False)
                  .agg(delta_qtd=("delta_qtd", "sum"),
                       delta_financeiro=("delta_financeiro", "sum")))

    # Une com posição inicial
    pos = pos_inicial.merge(mov_agg, on=["fundo", "ativo"], how="outer")
    pos["quantidade"] = pos["quantidade"].fillna(0)
    pos["delta_qtd"] = pos["delta_qtd"].fillna(0)
    pos["qtd_interno"] = pos["quantidade"] + pos["delta_qtd"]

    # Mantém só o que tem posição diferente de zero
    pos = pos[pos["qtd_interno"] != 0].copy()

    # Determina tipo se faltar (caso o ativo não estivesse na posição inicial)
    pos["tipo"] = pos["tipo"].fillna(
        pos["ativo"].apply(lambda a: "RF" if any(p in a for p in ["LFT", "NTNB", "CDB", "DEB"]) else "ACAO")
    )

    return pos[["fundo", "ativo", "tipo", "qtd_interno"]].reset_index(drop=True)


# ============================================================================
# 3) CONCILIAÇÃO COM CUSTÓDIA
# ============================================================================
def conciliar_custodia(pos_interna: pd.DataFrame,
                       custodia: pd.DataFrame) -> pd.DataFrame:
    """
    Cruza posição interna x custódia. Marca o status da divergência.
    """
    print("[2/4] Conciliando com custódia...")

    cust = custodia[["fundo", "ativo", "qtd_custodia"]].copy()
    conc = pos_interna.merge(cust, on=["fundo", "ativo"], how="outer", indicator=True)
    conc["qtd_interno"] = conc["qtd_interno"].fillna(0)
    conc["qtd_custodia"] = conc["qtd_custodia"].fillna(0)
    conc["diferenca"] = conc["qtd_interno"] - conc["qtd_custodia"]

    def classificar(row):
        if row["_merge"] == "left_only":
            return "SO_INTERNO"      # custódia não tem
        if row["_merge"] == "right_only":
            return "SO_CUSTODIA"     # interno não tem (provavelmente evento corp.)
        if abs(row["diferenca"]) < 0.0001:
            return "OK"
        return "DIVERGENTE"

    conc["status_conciliacao"] = conc.apply(classificar, axis=1)
    conc = conc.drop(columns="_merge")

    qtd_ok = (conc["status_conciliacao"] == "OK").sum()
    qtd_div = (conc["status_conciliacao"] != "OK").sum()
    print(f"      ✓ {qtd_ok} posições OK, {qtd_div} com divergência")

    return conc


# ============================================================================
# 4) MARCAÇÃO A MERCADO
# ============================================================================
def marcar_mercado(pos_interna: pd.DataFrame,
                   precos: pd.DataFrame,
                   boletas: pd.DataFrame,
                   pos_inicial: pd.DataFrame) -> pd.DataFrame:
    """
    Aplica preço de fechamento sobre a quantidade pra obter valor de mercado.
    Calcula também P&L do dia (diferença entre fechamento e preço médio do dia).
    """
    print("[3/4] Marcando a mercado...")

    p = precos.rename(columns={"preco_fechamento": "preco_mercado"})[["ativo", "preco_mercado"]]

    # Preço médio do dia (média ponderada das boletas) — pra estimar P&L de boletas novas
    pmd = (boletas.groupby(["fundo", "ativo"])
                  .apply(lambda g: (g["preco"] * g["quantidade"]).sum() / g["quantidade"].sum())
                  .reset_index(name="preco_medio_dia"))

    mtm = pos_interna.merge(p, on="ativo", how="left")
    mtm = mtm.merge(pmd, on=["fundo", "ativo"], how="left")
    mtm = mtm.merge(pos_inicial[["fundo", "ativo", "preco_medio"]],
                    on=["fundo", "ativo"], how="left")

    mtm["preco_mercado"] = mtm["preco_mercado"].fillna(0)
    mtm["valor_mercado"] = mtm["qtd_interno"] * mtm["preco_mercado"]

    # P&L unitário usando preço médio histórico (simplificação)
    mtm["preco_referencia"] = mtm["preco_medio"].fillna(mtm["preco_medio_dia"])
    mtm["pnl_dia"] = (mtm["preco_mercado"] - mtm["preco_referencia"]) * mtm["qtd_interno"]
    mtm["pnl_dia"] = mtm["pnl_dia"].fillna(0)

    return mtm


# ============================================================================
# 5) CÁLCULO DE PL E COTA
# ============================================================================
def calcular_pl_e_cota(mtm: pd.DataFrame, boletas: pd.DataFrame) -> pd.DataFrame:
    """
    PL do fundo = soma(valor_mercado) + caixa atualizado.
    Caixa atualizado = caixa inicial + vendas - compras (do dia).
    """
    print("[4/4] Calculando PL e cota por fundo...")

    # caixa do dia
    boletas["sinal"] = np.where(boletas["lado"] == "C", -1, 1)
    fluxo_caixa = (boletas.assign(fluxo=boletas["sinal"] * boletas["valor_financeiro"])
                          .groupby("fundo")["fluxo"].sum())

    # ativos por fundo
    ativos_fundo = mtm.groupby("fundo")["valor_mercado"].sum()

    pl = pd.DataFrame({"fundo": list(COTA_ANTERIOR.keys())})
    pl["valor_ativos"] = pl["fundo"].map(ativos_fundo).fillna(0)
    pl["caixa_inicial"] = pl["fundo"].map(CAIXA_INICIAL)
    pl["fluxo_caixa_dia"] = pl["fundo"].map(fluxo_caixa).fillna(0)
    pl["caixa_final"] = pl["caixa_inicial"] + pl["fluxo_caixa_dia"]
    pl["pl_total"] = pl["valor_ativos"] + pl["caixa_final"]
    pl["cotas_circulacao"] = pl["fundo"].map(COTAS_CIRCULACAO)
    pl["cota_hoje"] = pl["pl_total"] / pl["cotas_circulacao"]
    pl["cota_ontem"] = pl["fundo"].map(COTA_ANTERIOR)
    pl["rentabilidade_dia"] = (pl["cota_hoje"] - pl["cota_ontem"]) / pl["cota_ontem"]
    pl["data_pregao"] = DATA_PREGAO

    return pl


# ============================================================================
# 6) EXPORTAÇÃO PRO POWER BI
# ============================================================================
def exportar(conc: pd.DataFrame, mtm: pd.DataFrame, pl: pd.DataFrame,
             boletas: pd.DataFrame):
    print("[OK] Exportando resultados...")
    OUT = BASE / "output"
    OUT.mkdir(exist_ok=True)

    # Excel consolidado
    xlsx = OUT / "backoffice_resultado.xlsx"
    with pd.ExcelWriter(xlsx, engine="openpyxl") as writer:
        conc.to_excel(writer, sheet_name="Conciliacao_Custodia", index=False)
        mtm.to_excel(writer, sheet_name="Marcacao_Mercado", index=False)
        pl.to_excel(writer, sheet_name="PL_Cota_Fundos", index=False)
        boletas.to_excel(writer, sheet_name="Boletas_Dia", index=False)

    # CSVs separados (formato tidy pro Power BI)
    csv_dir = OUT / "powerbi_data"
    csv_dir.mkdir(exist_ok=True)
    conc.to_csv(csv_dir / "fato_conciliacao.csv", sep=";", index=False, encoding="utf-8-sig")
    mtm.to_csv(csv_dir / "fato_posicoes.csv", sep=";", index=False, encoding="utf-8-sig")
    pl.to_csv(csv_dir / "fato_pl_fundos.csv", sep=";", index=False, encoding="utf-8-sig")
    boletas.to_csv(csv_dir / "fato_boletas.csv", sep=";", index=False, encoding="utf-8-sig")

    # Tabela dimensão de fundos
    dim_fundos = pd.DataFrame({
        "fundo": list(COTA_ANTERIOR.keys()),
        "tipo_fundo": ["Ações", "Multimercado", "Renda Fixa", "Ações", "Multimercado"],
        "benchmark": ["Ibovespa", "CDI", "CDI", "IDIV", "CDI"],
    })
    dim_fundos.to_csv(csv_dir / "dim_fundos.csv", sep=";", index=False, encoding="utf-8-sig")

    print(f"      ✓ Excel: {xlsx}")
    print(f"      ✓ CSVs Power BI: {csv_dir}/")


# ============================================================================
def main():
    print("=" * 60)
    print("BACKOFFICE ALPHA CAPITAL — Pipeline Diário")
    print("=" * 60)
    dados = carregar_dados()

    pos_interna = calcular_posicao_interna(dados["pos_inicial"], dados["boletas"])
    conc = conciliar_custodia(pos_interna, dados["custodia"])
    mtm = marcar_mercado(pos_interna, dados["precos"], dados["boletas"], dados["pos_inicial"])
    pl = calcular_pl_e_cota(mtm, dados["boletas"])

    exportar(conc, mtm, pl, dados["boletas"])

    # Resumo no console
    print("\n" + "=" * 60)
    print("RESUMO DO DIA — " + DATA_PREGAO)
    print("=" * 60)
    print("\n>>> PL e cota por fundo:")
    resumo = pl[["fundo", "pl_total", "cota_hoje", "rentabilidade_dia"]].copy()
    resumo["pl_total"] = resumo["pl_total"].apply(lambda x: f"R$ {x:>16,.2f}")
    resumo["cota_hoje"] = resumo["cota_hoje"].apply(lambda x: f"{x:.6f}")
    resumo["rentabilidade_dia"] = resumo["rentabilidade_dia"].apply(lambda x: f"{x*100:+.4f}%")
    print(resumo.to_string(index=False))

    print("\n>>> Status da conciliação com custódia:")
    print(conc["status_conciliacao"].value_counts().to_string())

    print("\n[OK] Pipeline concluído.")


if __name__ == "__main__":
    main()
